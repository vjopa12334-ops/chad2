# 🤖 Telegram Beauty Analyzer Bot

Анализирует внешность по фото с помощью **DeepFace** и **MediaPipe**.

## Что умеет

| Параметр | Источник |
|---|---|
| Возраст | DeepFace |
| Пол | DeepFace |
| Эмоция | DeepFace |
| Этническая группа | DeepFace |
| Симметрия лица (0-100) | MediaPipe FaceMesh |
| Общая оценка (1-10) | Комбинация выше |

## Быстрый старт (локально)

```bash
# 1. Клонируй / скачай проект
# 2. Создай .env
cp .env.example .env
# Вставь токен от @BotFather

# 3. Docker Compose
docker compose up --build
```

## Деплой на Railway

1. Залей код в GitHub репозиторий
2. Открой [railway.app](https://railway.app) → New Project → Deploy from GitHub
3. В разделе **Variables** добавь:
   ```
   BOT_TOKEN = твой_токен
   ```
4. Railway автоматически найдёт `railway.toml` и `Dockerfile` → задеплоит

> ✅ Веса DeepFace скачиваются **во время сборки образа** (не при первом запросе), поэтому Railway не крашится из-за таймаута.

## Структура проекта

```
├── bot.py            # Telegram handlers
├── analyzer.py       # DeepFace + MediaPipe логика
├── requirements.txt
├── Dockerfile        # Multi-stage build
├── docker-compose.yml
├── railway.toml      # Railway конфиг
└── .env.example
```

## Примечания

- Используется `retinaface` как детектор лиц — точный, но медленный (~3-8 сек).  
  Если нужна скорость, замени на `"opencv"` в `analyzer.py`.
- Все фото обрабатываются **локально**, никуда не отправляются.
- Минимум 1 чёткое лицо на фото, иначе бот сообщит об ошибке.
