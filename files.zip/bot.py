import os
import logging
import asyncio
import tempfile
from pathlib import Path

from telegram import Update, ReplyKeyboardMarkup, KeyboardButton
from telegram.ext import (
    Application,
    CommandHandler,
    MessageHandler,
    filters,
    ContextTypes,
)

from analyzer import analyze_photo

logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    level=logging.INFO,
)
logger = logging.getLogger(__name__)

BOT_TOKEN = os.environ.get("BOT_TOKEN", "")


# ─────────────────────────── handlers ────────────────────────────

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    keyboard = [[KeyboardButton("📸 Отправить фото для анализа")]]
    markup = ReplyKeyboardMarkup(keyboard, resize_keyboard=True)
    await update.message.reply_text(
        "👋 Привет! Я бот для анализа внешности.\n\n"
        "📸 Отправь мне фото лица, и я определю:\n"
        "• Возраст и пол\n"
        "• Эмоцию\n"
        "• Расу\n"
        "• Симметрию лица (MediaPipe)\n"
        "• Общую оценку\n\n"
        "⚠️ Анализ выполняется локально — фото никуда не отправляются.",
        reply_markup=markup,
    )


async def help_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await update.message.reply_text(
        "ℹ️ Просто пришли фото с лицом — я сделаю всё остальное.\n"
        "Для лучшего результата:\n"
        "• Хорошее освещение\n"
        "• Лицо смотрит прямо в камеру\n"
        "• Один человек на фото"
    )


async def handle_photo(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    msg = await update.message.reply_text("⏳ Анализирую фото, подожди немного...")

    try:
        photo = update.message.photo[-1]  # largest resolution
        file = await photo.get_file()

        with tempfile.NamedTemporaryFile(suffix=".jpg", delete=False) as tmp:
            tmp_path = tmp.name

        await file.download_to_drive(tmp_path)

        loop = asyncio.get_event_loop()
        result = await loop.run_in_executor(None, analyze_photo, tmp_path)

        Path(tmp_path).unlink(missing_ok=True)

        await msg.edit_text(result, parse_mode="HTML")

    except Exception as e:
        logger.exception("Error during analysis")
        await msg.edit_text(
            f"❌ Ошибка при анализе:\n<code>{str(e)}</code>\n\n"
            "Убедись, что на фото есть чёткое лицо.",
            parse_mode="HTML",
        )


async def handle_text(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await update.message.reply_text(
        "📸 Пришли фото для анализа.\nИспользуй /start чтобы увидеть инструкцию."
    )


# ─────────────────────────── main ────────────────────────────────

def main() -> None:
    if not BOT_TOKEN:
        raise ValueError("BOT_TOKEN env variable is not set!")

    app = Application.builder().token(BOT_TOKEN).build()

    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("help", help_cmd))
    app.add_handler(MessageHandler(filters.PHOTO, handle_photo))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_text))

    logger.info("Bot started. Polling...")
    app.run_polling(allowed_updates=Update.ALL_TYPES)


if __name__ == "__main__":
    main()
