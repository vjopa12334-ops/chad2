"""
analyzer.py — combines DeepFace + MediaPipe for facial analysis.
"""

import math
import logging
from typing import Optional

import cv2
import numpy as np

logger = logging.getLogger(__name__)


# ──────────────────────────── helpers ────────────────────────────

def _load_image(path: str) -> np.ndarray:
    img = cv2.imread(path)
    if img is None:
        raise ValueError("Не удалось загрузить изображение.")
    return img


def _deepface_analyze(path: str) -> dict:
    """Run DeepFace analysis — imported lazily to speed up startup."""
    from deepface import DeepFace  # noqa: PLC0415

    results = DeepFace.analyze(
        img_path=path,
        actions=["age", "gender", "emotion", "race"],
        enforce_detection=True,
        detector_backend="retinaface",
        silent=True,
    )
    # DeepFace can return a list when multiple faces are found
    if isinstance(results, list):
        results = results[0]
    return results


# ──────────────────────────── MediaPipe symmetry ────────────────────

def _mediapipe_symmetry(path: str) -> Optional[float]:
    """
    Returns a symmetry score 0-100 using MediaPipe Face Mesh.
    Works by comparing distances of mirrored landmark pairs.
    """
    try:
        import mediapipe as mp  # noqa: PLC0415

        mp_face_mesh = mp.solutions.face_mesh

        img_bgr = _load_image(path)
        img_rgb = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2RGB)
        h, w = img_rgb.shape[:2]

        # Pairs of landmarks that should be symmetric (left, right)
        SYMMETRIC_PAIRS = [
            (33, 263),   # outer eye corners
            (133, 362),  # inner eye corners
            (70, 300),   # eyebrow outer
            (105, 334),  # eyebrow inner
            (187, 411),  # cheek
            (234, 454),  # jaw sides
            (61, 291),   # mouth corners
            (57, 287),   # lip edges
            (0, 17),     # chin (reference — same point mirrored)
        ]

        with mp_face_mesh.FaceMesh(
            static_image_mode=True,
            max_num_faces=1,
            refine_landmarks=True,
            min_detection_confidence=0.5,
        ) as face_mesh:
            results = face_mesh.process(img_rgb)

        if not results.multi_face_landmarks:
            return None

        lm = results.multi_face_landmarks[0].landmark
        pts = [(lm[i].x * w, lm[i].y * h) for i in range(len(lm))]

        # Use nose tip (landmark 1) as the symmetry axis
        nose_x = pts[1][0]

        diffs = []
        for left_idx, right_idx in SYMMETRIC_PAIRS:
            lx, ly = pts[left_idx]
            rx, ry = pts[right_idx]

            # Mirror both points around the nose axis
            l_dist = abs(lx - nose_x)
            r_dist = abs(rx - nose_x)

            # Vertical difference
            y_diff = abs(ly - ry) / h

            # Horizontal asymmetry relative to face width
            h_asym = abs(l_dist - r_dist) / w

            diffs.append(h_asym + y_diff * 0.5)

        mean_diff = sum(diffs) / len(diffs)
        # Convert to 0-100 score; empirically ~0.02 is quite symmetric
        score = max(0.0, min(100.0, 100.0 * (1 - mean_diff / 0.08)))
        return round(score, 1)

    except Exception as e:
        logger.warning("MediaPipe symmetry failed: %s", e)
        return None


# ──────────────────────────── scoring ────────────────────────────

def _beauty_score(
    age: int,
    gender: str,
    dominant_emotion: str,
    symmetry: Optional[float],
) -> float:
    """
    Heuristic beauty/attractiveness score 1-10.
    Combines symmetry, neutral/positive emotion, and demographic priors.
    """
    score = 5.0  # baseline

    # Symmetry bonus (up to +2.5)
    if symmetry is not None:
        score += (symmetry - 50) / 20  # ±2.5

    # Emotion modifier
    emotion_weights = {
        "happy": +1.0,
        "neutral": +0.3,
        "surprise": +0.0,
        "sad": -0.5,
        "angry": -0.8,
        "fear": -0.6,
        "disgust": -1.0,
    }
    score += emotion_weights.get(dominant_emotion, 0)

    # Small age-related adjustment (peak ~20-35)
    if 20 <= age <= 35:
        score += 0.3
    elif age < 15 or age > 65:
        score -= 0.3

    return round(max(1.0, min(10.0, score)), 1)


def _score_bar(score: float) -> str:
    filled = int(score)
    bar = "⭐" * filled + "☆" * (10 - filled)
    return bar


def _symmetry_bar(sym: float) -> str:
    filled = int(sym / 10)
    bar = "█" * filled + "░" * (10 - filled)
    return bar


# ──────────────────────────── main entry ────────────────────────────

def analyze_photo(path: str) -> str:
    """Analyze a photo and return a formatted HTML result string."""

    # 1. DeepFace analysis
    df = _deepface_analyze(path)

    age: int = int(df.get("age", 0))
    gender_raw: str = df.get("dominant_gender", df.get("gender", "Unknown"))
    gender = "Мужской" if str(gender_raw).lower() in ("man", "male") else "Женский"
    emotion: str = df.get("dominant_emotion", "unknown")
    race: str = df.get("dominant_race", "unknown")

    emotion_map = {
        "happy": "😊 Радость",
        "neutral": "😐 Нейтральная",
        "sad": "😢 Грусть",
        "angry": "😠 Злость",
        "surprise": "😲 Удивление",
        "fear": "😨 Страх",
        "disgust": "🤢 Отвращение",
    }
    emotion_ru = emotion_map.get(emotion, f"❓ {emotion}")

    race_map = {
        "asian": "Азиатская",
        "indian": "Южноазиатская",
        "black": "Африканская",
        "white": "Европейская",
        "middle eastern": "Ближневосточная",
        "latino hispanic": "Латиноамериканская",
    }
    race_ru = race_map.get(race.lower(), race.capitalize())

    # 2. MediaPipe symmetry
    symmetry = _mediapipe_symmetry(path)

    # 3. Beauty score
    beauty = _beauty_score(age, gender, emotion, symmetry)
    bar = _score_bar(beauty)

    # 4. Format result
    lines = [
        "🔍 <b>Результат анализа внешности</b>",
        "",
        f"👤 <b>Пол:</b> {gender}",
        f"🎂 <b>Возраст:</b> ~{age} лет",
        f"🎭 <b>Эмоция:</b> {emotion_ru}",
        f"🌍 <b>Этническая группа:</b> {race_ru}",
    ]

    if symmetry is not None:
        sym_bar = _symmetry_bar(symmetry)
        lines.append(f"⚖️ <b>Симметрия лица:</b> {symmetry}/100")
        lines.append(f"   <code>{sym_bar}</code>")
    else:
        lines.append("⚖️ <b>Симметрия:</b> не удалось определить")

    lines += [
        "",
        f"✨ <b>Общая оценка:</b> {beauty}/10",
        f"   {bar}",
        "",
        "<i>Анализ выполнен локально с помощью DeepFace + MediaPipe</i>",
    ]

    return "\n".join(lines)
